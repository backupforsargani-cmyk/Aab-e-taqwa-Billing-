plugins { id("com.android.application") }
android { namespace = "com.aabetaqwa.billing"; compileSdk = 36
    defaultConfig { applicationId = "com.aabetaqwa.billing"; minSdk = 23; targetSdk = 36; versionCode = 1; versionName = "1.0" }
}
