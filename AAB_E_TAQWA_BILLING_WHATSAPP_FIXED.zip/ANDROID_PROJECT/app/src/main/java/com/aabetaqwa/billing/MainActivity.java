package com.aabetaqwa.billing;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    WebView w=new WebView(this);
    w.setBackgroundColor(Color.WHITE);
    w.getSettings().setJavaScriptEnabled(true);
    w.getSettings().setDomStorageEnabled(true);
    w.setWebViewClient(new WebViewClient());
    w.addJavascriptInterface(new ShareBridge(), "AndroidShare");
    w.loadUrl("file:///android_asset/index.html");
    setContentView(w);
  }

  public class ShareBridge {
    @JavascriptInterface public void shareImage(String dataUrl){
      try {
        String base64=dataUrl.substring(dataUrl.indexOf(',')+1);
        byte[] bytes=Base64.decode(base64, Base64.DEFAULT);
        File dir=new File(getCacheDir(),"share");
        dir.mkdirs();
        File file=new File(dir,"Aab-e-Taqwa-Bill.jpg");
        try(FileOutputStream out=new FileOutputStream(file)){ out.write(bytes); }
        Uri uri=FileProvider.getUriForFile(MainActivity.this, getPackageName()+".fileprovider", file);
        Intent send=new Intent(Intent.ACTION_SEND);
        send.setType("image/jpeg");
        send.putExtra(Intent.EXTRA_STREAM,uri);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
          send.setPackage("com.whatsapp");
          startActivity(send);
        } catch(Exception ex) {
          send.setPackage(null);
          startActivity(Intent.createChooser(send,"Share bill"));
        }
      } catch(Exception ex) {
        runOnUiThread(() -> android.widget.Toast.makeText(MainActivity.this,"Unable to share bill",android.widget.Toast.LENGTH_SHORT).show());
      }
    }
  }
}
