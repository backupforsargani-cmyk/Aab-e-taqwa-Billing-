AAB E TAQWA BILLING - APK BUILD

GitHub: open Actions -> Build Aab e Taqwa APK -> Run workflow.
After the green check, open the workflow run and download the artifact named Aab-e-Taqwa-Billing-APK.
